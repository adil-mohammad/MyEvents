import { NgModule }     from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent }  from '../controllers/app.component';


@NgModule({
  imports: [
    RouterModule.forRoot([
         
    ])
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}