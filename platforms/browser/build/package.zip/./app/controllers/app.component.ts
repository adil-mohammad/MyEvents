import {Component} from '@angular/core';

@Component({
  selector:'my-app',
  template: `In App Component`
  
})

export class AppComponent{
  
  
}
